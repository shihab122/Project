class Edge:
    def __init__(self, u, v, w):
        self.u = u
        self.v = v
        self.w = w